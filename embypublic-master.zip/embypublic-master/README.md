# EmbyPublic

https://embywiki.feverss.cloud/use-on-various-devices/use-on-ios/use-official-client/shi-yong-shadowrocket-po-jie
