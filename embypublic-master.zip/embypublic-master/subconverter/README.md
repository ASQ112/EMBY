# 用法

将 [emby_external_config.ini](https://gitlab.com/iptv-org/embypublic/-/raw/master/subconverter/emby_external_config.ini) 或 [emby_external_config.yml](https://gitlab.com/iptv-org/embypublic/-/raw/master/subconverter/emby_external_config.yml) 的地址 [URLEncode](https://www.urlencoder.org/) 经过处理后，加在 [subconverter](https://github.com/tindy2013/subconverter) 地址的 `&config=` 后面；

![sub-web](https://gitlab.com/iptv-org/embypublic/-/raw/master/subconverter/iShot2021-01-25_20.39.03.png)

或使用 [sub-web](https://sub-web.netlify.app) 生成地址时填写`远程配置`为 [emby_external_config.ini](https://gitlab.com/iptv-org/embypublic/-/raw/master/subconverter/emby_external_config.ini) 或 [emby_external_config.yml](https://gitlab.com/iptv-org/embypublic/-/raw/master/subconverter/emby_external_config.yml) 的地址。
